PyTorch Version: 2.8.0+cpu



Loading your trained models...

OK: ResNet-18 weights loaded.

OK: MobileNetV2 weights loaded.



Starting evaluation on the full test set...

Evaluating Images: 100%|█████████████████████████████████████████████████████████████| 1000/1000 \[09:24<00:00,  1.77it/s] 





**Metrics for ResNet-18**

----------------------

Accuracy: 0.9710



Classification Report:

&nbsp;               precision    recall  f1-score   support



&nbsp;     basophil       0.99      0.90      0.94       200

&nbsp; erythroblast       0.98      0.98      0.98       200

&nbsp;     monocyte       0.92      0.98      0.95       200

&nbsp;   myeloblast       0.99      0.99      0.99       200

seg\_neutrophil       0.99      1.00      0.99       200



&nbsp;     accuracy                           0.97      1000

&nbsp;    macro avg       0.97      0.97      0.97      1000

&nbsp; weighted avg       0.97      0.97      0.97      1000



ROC AUC Score (One-vs-Rest): 0.9992





**Metrics for MobileNetV2**

------------------------

Accuracy: 0.9860



Classification Report:

&nbsp;               precision    recall  f1-score   support



&nbsp;     basophil       0.98      0.96      0.97       200

&nbsp; erythroblast       0.99      0.99      0.99       200

&nbsp;     monocyte       0.97      0.98      0.97       200

&nbsp;   myeloblast       1.00      1.00      1.00       200

seg\_neutrophil       1.00      1.00      1.00       200



&nbsp;     accuracy                           0.99      1000

&nbsp;    macro avg       0.99      0.99      0.99      1000

&nbsp; weighted avg       0.99      0.99      0.99      1000



ROC AUC Score (One-vs-Rest): 0.9996





Evaluation complete.



Invoke-WebRequest -Uri https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip -OutFile ngrok.zip

Expand-Archive .\\ngrok.zip -DestinationPath .\\ngrok

.\\ngrok\\ngrok.exe config add-authtoken 1wdCj749qAe6YwqYvrPqeIMJnnM\_5Wc95LRUoqXYqV1ZDa6gf

.\\ngrok\\ngrok.exe --version



.\\ngrok\\ngrok.exe http 5000





