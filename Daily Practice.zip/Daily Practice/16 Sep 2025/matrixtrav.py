size = int(input("Enter size of matrix: "))
matrix = [list(map(int, input("Enter row: ").split())) for _ in range(size)]

for j in matrix:
    print(j)

res = []

while matrix:
    res += matrix.pop(0)
    matrix = list(zip(*matrix))[::-1]

print(res)