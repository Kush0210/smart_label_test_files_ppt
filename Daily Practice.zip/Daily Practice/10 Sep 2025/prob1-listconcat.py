list1 = list(map(int, input("Enter list 1: ").split(" ")))
list2 = list(map(int, input("Enter list 2: ").split(" ")))

res = [None] * (len(list1) + len(list2))

i = 0
for item in list1:
    res[i] = item
    i += 1

for item in list2:
    res[i] = item
    i += 1

print(sorted(res))