from collections import Counter

nums = list(map(int, input("Enter nums: ").split(" ")))
counts = Counter(nums)
