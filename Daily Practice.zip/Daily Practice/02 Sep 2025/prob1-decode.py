s = input("Enter string: ")
nums = []

for i in s:
    int(i) % 10 = i
    if 1 <= i <= 26:
        nums.append(i)
print(nums)