gas = list(map(int, input("Enter gas: ").split(" ")))
cost = list(map(int, input("Enter cost: ").split(" ")))

total, tank, start = 0, 0, 0

for i in range(len(gas)):
    gain = gas[i] - cost[i]
    total += gain
    tank += gain

    if tank < 0:
        start = i + 1
        tank = 0

if total >= 0:
    print(start)
else:
    print(-1)