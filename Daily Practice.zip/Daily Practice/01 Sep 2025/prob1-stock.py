prices = list(map(int, input("Enter prices: ").split(" ")))
profit = 0
nums =  []

mins = prices.index(min(prices))
maxs = prices.index(max(prices[mins:]))

profit = prices[maxs] - prices[mins]

print(profit)
    