str1 = list(sorted(input("Enter String 1: ")))
str2 = list(sorted(input("Enter String 2: ")))

if str1 == str2: print("Anagrams")
else: print("Nahhhhhhhhhhhh")

# dict1 = dict(enumerate(str1))
# dict2 = dict(enumerate(str2))

# print(dict1)
# print(dict2)

# if dict1 == dict2:
#     print("Anagrams")
# else:
#     print("Nahhhhhhhhhhhh")