coins = list(sorted(map(int, input("Enter coins: ").split())))[::-1]
target = int(input("Enter target: "))
ans = []

for i in range(len(coins)):
    while(coins[i] <= target):
        ans.append(coins[i])
        target = target - coins[i]

if target == 0 :
    print(ans)
    print(len(ans))
else:
    print("-1")