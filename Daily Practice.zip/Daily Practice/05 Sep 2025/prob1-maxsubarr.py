nums = list(map(int, input("Enter nums: ").split(" ")))
subarrs = []
sum_subarrs = []

for i in range(len(nums)):
    for j in range(i, len(nums)):
        subarrs.append(nums[i : j + 1])
        sum_subarrs.append(sum(nums[i : j + 1]))
        
# print("Sub arrays:",subarrs)
# print("Sum of sub arrays:", sum_subarrs)
# print()
print("Maximum sum of sub arrays:", max(sum_subarrs))
# print("Index of Maximum sum of sub arrays:", sum_subarrs.index(max(sum_subarrs)))
print("Sub array of max element:", subarrs[sum_subarrs.index(max(sum_subarrs))])