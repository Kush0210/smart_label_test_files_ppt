# # product of arr except itself

# arr = list(map(int, input("Enter nums: ").split(" ")))
# res = []

# for i in range(len(arr)):
#     prod = 1
#     for j in range(len(arr)):
#         if i == j:
#             continue
#         prod *= arr[j]
#     res.append(prod)
# print(res)

def product_except_self(nums):
    n = len(nums)
    result = [1] * n

    # Calculate prefix products
    prefix = 1
    for i in range(n):
        result[i] = prefix
        prefix *= nums[i]

    # Calculate suffix products and multiply with prefix
    suffix = 1
    for i in range(n - 1, -1, -1):
        result[i] *= suffix
        suffix *= nums[i]

    return result

# Example usage
arr = list(map(int, input("Enter nums: ").split(" ")))
print("Input:", arr)
print("Output:", product_except_self(arr))
