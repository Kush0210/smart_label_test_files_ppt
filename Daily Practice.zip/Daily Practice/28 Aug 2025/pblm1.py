def subarr(nums, k):
	n = len(nums)
	ans = n + 1

	for i in range(n):
		total = 0
		for j in range(i , n):
			total += nums[j]
			if total >= k:
				if(j - i + 1) < ans:
					ans = j - i + 1
				break

	if ans <= n:
		return ans
	else:
		return -1

num = list(map(int, input("Enter nums: ").split()))
kk = int(input("Enter k: "))

print("Length of shortest subarray: ", subarr(num, kk))