nums = list(map(int, input("Enter nums: ").split(" ")))
n = len(nums)
sum = []
total = 0

for i in range(n):
    for j in range(i,n):
        for k in range(j,n):
            if (i != j) and (i != k) and (j != k ) and (nums[i] + nums[j] + nums[k] == 0):
                # total = nums[i] + nums[j] + nums[k]
                sum.append([nums[i], nums[j], nums[k]])

# print(total)


print(sum)

# if sum[0][1] == sum[2][0]:
#     print("true")