from collections import Counter

nums = list(map(int, input("Enter nums: ").split(" ")))
k = int(input("Enter k: "))

subarrs = []
sum_subarrs = []
count = 0

for i in range(len(nums)):
    for j in range(i, len(nums)):
        subarrs.append(nums[i : j + 1])
        sum_subarrs.append(sum(nums[i : j + 1]))

for i in range(len(sum_subarrs)):
    if sum_subarrs[i] == k:
        count += 1
        # print(sum_subarrs[i])

print(subarrs)
print(sum_subarrs)
print(count)