from collections import Counter
vowels = ['a', 'e', 'i', 'o', 'u']
s = input("Enter string: ").lower()
s_vowels = []
s_conso = []

for i in s:
    if i in vowels:
        s_vowels.append(i)
    else:
        s_conso.append(i)

count_vowels = Counter(s_vowels)
count_conso = Counter(s_conso)

max_vowels = max(count_vowels.values())
max_conso = max(count_conso.values())

sum = max_vowels + max_conso

print("Vowels:",count_vowels)
print("Consonants:",count_conso)
print("Max Num of Vowels:",max_vowels)
print("Max Num of Consonants:",max_conso)
print("Sum:",sum)