n = int(input("Enter n: "))
k = int(input("Enter k: "))

factors = []
for i in range(1, n + 1):
    if n % i == 0:
        factors.append(i)

if len(factors) >= k:
    print("kth factor of n:",factors[k-1])
else:
    print("n has fewer factors than k: -1")

# def kthfactor(n, k):
#     count = 0
#     for i in range(1, n + 1):
#         if n % i == 0:
#             count = count + 1
#             if count == k:
#                 print(i)
#     if count < k :
#         print(-1)
        

# kthfactor(4,4)