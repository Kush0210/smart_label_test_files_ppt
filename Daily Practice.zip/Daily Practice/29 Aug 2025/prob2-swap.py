num = list(map(int, input("Enter num: ")))
# print(max(num))

max_num = num

# temp = num[0]
# if num[0] < num[1]:
#     temp = max_num[0]
#     max_num[0] = max_num[1]
#     max_num[1] = temp

# final_num = int("".join(map(str, max_num)))
# print(final_num)


maxxx = max(max_num)
index = max_num.index(maxxx)
if num[0] < max(num):
    temp = max_num[0]
    max_num[0] = maxxx
    max_num[index] = temp

final_num = int("".join(map(str, max_num)))
print(final_num)